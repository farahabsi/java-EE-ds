
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns = {"/MyServlet"})
public class MyServlet extends HttpServlet {

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    String action= (String) request.getParameter("Submit");
    if(action.equals("Valider")){
        
    String nom=request.getParameter("nom");    
    String prenom=request.getParameter("prenom");  
    String nsalle=request.getParameter("ns");  
    String npc=request.getParameter("np");
    String panne=request.getParameterValues("radio1")[0];
    String degreeu=request.getParameterValues("radio2")[0];
    String description=request.getParameter("textarea");
       
       boolean b_nsalle=false;
       try{
       Integer.parseInt(nsalle);
       b_nsalle=true;
       
       }catch(NumberFormatException e){
               
               }
       boolean b_npc=false;
       try{
       Integer.parseInt(npc);
       b_npc=true;
       
       }catch(NumberFormatException e){
               
               }
       
    if((Character.isLowerCase(nom.charAt(0)))||(Character.isLowerCase(prenom.charAt(0)))||description.length()>200||b_npc==false||b_nsalle==false) {
     this.getServletContext().getRequestDispatcher("/Inscription.jsp").forward(request, response);
    }  else{
    request.setAttribute("nom", nom);
    request.setAttribute("prenom", prenom);
    request.setAttribute("nsalle", nsalle);
    request.setAttribute("npc", npc);   
    request.setAttribute("panne", panne); 
    request.setAttribute("description", description); 
    request.setAttribute("degreeu", degreeu); 
    this.getServletContext().getRequestDispatcher("/Inscription_succ.jsp").forward(request, response);
    }
     
    }
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
